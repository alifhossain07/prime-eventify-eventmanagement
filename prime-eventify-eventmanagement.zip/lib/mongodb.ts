// lib/mongodb.ts

import { MongoClient, ServerApiVersion } from "mongodb";

// Get the MongoDB URI from environment variables
const uri = process.env.MONGODB_URI || "";

const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  },
});

export const connectToDatabase = async () => {
  try {
    // Check if the MongoDB URI is present
    if (!uri) {
      throw new Error("MongoDB URI is missing from environment variables");
    }

    // Connect to MongoDB
    await client.connect();

    // Send a ping to confirm a successful connection
    await client.db("admin").command({ ping: 1 });
    console.log("Pinged your deployment. You successfully connected to MongoDB!");

    const db = client.db(); // Get default database
    return { db, client };
  } catch (error) {
    console.error("Error connecting to MongoDB:", error);
    throw error;
  }
};
