import { clerkMiddleware, createRouteMatcher } from '@clerk/nextjs/server'

// Create a route matcher to exclude Clerk's auth routes from being protected
const isPublicRoute = createRouteMatcher([
  '/sign-in(.*)',   // match any path starting with /sign-in
  '/sign-up(.*)',   // match any path starting with /sign-up
  '/register(.*)',  // match any path starting with /register
])

export default clerkMiddleware(async (auth, req) => {
  // Protect all routes except the public ones (sign-in, sign-up, register)
  if (!isPublicRoute(req)) {
    await auth.protect()
  }
})

export const config = {
  matcher: [
    // Skip Next.js internals and all static files
    '/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|webp|png|gif|svg|ttf|woff2?|ico|csv|docx?|xlsx?|zip|webmanifest)).*)',
    
    // Always run for API routes
    '/(api|trpc)(.*)',
  ],
}
